# IPAM Lite — Jen Plugin

Full IP address space management for Jen — covering both Kea-managed subnets and unmanaged (non-DHCP) networks. See every IP in each subnet at a glance — available, dynamic DHCP lease, Kea reservation, statically noted, or planned for future use. Add labels, owners, and notes to any address. Import from Netbox or other IPAM tools. Replaces Netbox for simple static IP tracking.

> **IPv4 only.** As of Jen v5.0's IPv6 rollout, IPAM Lite covers IPv4 subnets exclusively — full-address-space enumeration doesn't extend to IPv6's /64s (see Jen's `docs/ARCHITECTURE.md` for why). For IPv6 lease and reservation counts, use Jen's own Subnets/Leases/Reservations pages instead. This isn't a bug or a gap to report — it's a deliberate v5.0 scope decision.

## Requirements

- [Jen](https://github.com/ltkojak/jen-kea) v5.68.0 or later (v1.6.x runs on 5.65.10+; v1.5.x on 5.34.0+)

## Features

- **Overview page** — all subnets as cards with stacked utilisation bars (dynamic / reserved / static / planned / infrastructure / conflict / available), counted without enumerating the address space
- **Unmanaged subnets** — track non-DHCP networks Kea doesn't manage (backend networks, management VLANs, etc.). Admins add them by name + CIDR; addresses support manual hostname and MAC since there's no DHCP to supply them
- **Subnet detail** — every IP with its current status and annotations, as a phone-friendly rowlist; the gateway, DNS servers, DHCP pools and the Kea/Jen hosts (from Jen's own subnet context) are shown and labelled as **infrastructure**, addresses inside a DHCP pool carry a `pool` badge, and runs of available addresses collapse into one row on every subnet (`?all=1` shows them all)
- **Next free** — the first available address outside every DHCP pool, one click
- **Devices** — a lease's row shows the device Jen knows for that MAC (name, vendor, icon); Owner prefills from it
- **Conflict** — a static/planned entry whose address a DHCP client now holds is flagged, not silently shown as a lease. A periodic check alerts once per new conflict (Settings → Alerts, type "IPAM Conflict") and emits an event for the Timeline
- **Search + JSON API** — entries show up in Jen's global search by label, owner, IP or hostname; `GET/POST /api/v1/plugins/ipam/entries` and `GET /api/v1/plugins/ipam/next-free/<subnet_id>` for scripting, authenticated with a Jen API key and scoped to the subnets that key is allowed (a key with no scope reaches every subnet)
- **"Open in IPAM"** row action on Jen's own Reservations page, linking straight to that address
- **Investigate** on every address row that names a client (its MAC, or its address when a static or planned entry has no MAC) and beside each MAC in the import preview, Jen's own action for a row that names a client
- **On the Investigation page** (Jen 5.68.0): a card under "What else Jen knows" with IPAM's entry for each address a client holds - static, planned or annotated - and whether the client is the one it was designated for; a conflict or a different designee is a "Needs a look" card
- **Range…** — mark a from–to span planned/static (one label/owner) or clear it; leases and reservations are never overwritten
- **Edit modal** — context-aware per IP status:
  - Dynamic / Reserved: notes only (Kea controls identity)
  - Available / Static / Planned: label, owner, notes, and status toggle. Typing anything while an address is Available auto-switches it to Static — pick Planned yourself if that's what you mean instead
  - Manual hostname and MAC on any subnet (a static host has no lease to supply them; Network Discovery matches on the MAC)
- **Static designation** — mark IPs as statically assigned (router, NAS, printer, etc.) without touching Kea
- **Planned designation** — earmark an IP for something coming up without calling it a DHCP reservation
- **Import** — bring in addresses from a Jen export, Netbox's IP Addresses export, or a generic CSV (column names are matched automatically). Preview and confirm before anything is written
- **Search + filter** — live client-side search across IP, hostname, label, MAC, owner, and notes; status filter tabs
- **CSV export** per subnet — Jen's own format and a Netbox-shaped one; every cell passes a formula-injection guard
- **Assignment history** logged with user and timestamp (UTC), shown per address in the edit modal, in a Recent changes panel, and exportable
- Respects Jen subnet access control: a user restricted to specific Kea subnets sees only those, and none of the unmanaged subnets; unmanaged subnet add/delete needs an admin who can see every subnet, and viewers are read-only: every change needs admin

## Recorded for the audit trail, not displayed

Some columns are written and never read back by this plugin, and are kept rather than dropped: `ipam_static_entries.created_at` and `ipam_subnets.created_at` (when the row was first made; shown nowhere, while `updated_at` is read to order search results), and `ipam_conflict_state.first_detected` and `last_seen` (the conflict check inserts a row the first time it alerts, refreshes `last_seen` while the conflict lasts and deletes the row when it clears; only the row's existence and key are read, to alert once per conflict). The per-address change history (`ipam_assignment_history`, including who made each change) is shown, exported and not affected.

## Migration notes

Two of the 16 migrations in `manifest.json` have an unusual history that a reader of the file should know. **Migration 1** was edited after it had been released: the original `CREATE TABLE` declared `ip VARCHAR(15) NOT NULL UNIQUE`, and Jen 5.28.2 (the release that made the plugin's migrations portable to MySQL 8) shipped it without the `UNIQUE`, because migration 8 drops that very index and a fresh install would otherwise create it only to drop it. A box that installed earlier ran the old statement and still has the index until migration 8 removes it; a box that installs now never has it. **Migration 8** (`ALTER TABLE ipam_static_entries DROP INDEX ip`) therefore fails on a fresh install with "can't DROP" (error 1091), and relies on Jen's migration runner treating that error, like duplicate column (1060) and duplicate key name (1061), as the change already being in effect and recording the migration as applied. A released migration is not rewritten again (it would fork what existing installs have already run); a new schema change is always a new numbered migration.

## Installation

Open Jen → **Settings → Plugins** and click **Install** next to IPAM Lite. Jen downloads the release pinned in its plugin registry, verifies its checksum, and enables it; restart Jen when prompted.

To install by hand instead (a checkout without registry access), unzip `plugin.zip` from the release tag you want into `/var/lib/jen/plugins/ipam/`, then enable it from Settings → Plugins and restart Jen.

## Development

`python3 tools/verify.py --build` rebuilds `plugin.zip` deterministically from the tree and runs the same checks CI runs on every push and tag: the zip matches the tree byte-for-byte, no template carries an inline event handler, an inline `style=` attribute or an un-nonce'd `<script>` (Jen's CSP executes neither of the first and last), `manifest.json`'s version matches the top `CHANGELOG.md` entry, and `plugin.py` compiles and passes ruff. The committed `plugin.zip` is the artifact Jen installs, so rebuild it in the same commit as any change.

## Version History

See [CHANGELOG.md](CHANGELOG.md).

## License

GPL v3 — Copyright 2026 Matthew Thibodeau
