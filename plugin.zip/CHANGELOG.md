# IPAM Lite Plugin — Changelog

## [1.6.4] - 2026-09-27

Jen's Q100 sweep: every bundled plugin moves onto the small helpers Jen 5.65.10 added, and this is the
first of them to also carry its own performance work, since IPAM was the plugin most exposed to a large
subnet.

### Changed: onto Jen's shared helpers

The MAC check, the search-LIKE escaping and the subnet-not-found check now delegate to
`jen.plugin_api.normalize_mac` / `like_pattern` / `assert_subnet_access(notify=)` instead of carrying
their own copies. Requires Jen 5.65.10.

### Fixed: the detail page, export and next-free materialised the whole subnet first

Every one of them built a Python dict for every host address before doing anything else - `[str(h) for h
in network.hosts()]` - so a Kea /16 (65,534 addresses) cost roughly a second and tens of megabytes on
every detail-page load, every CSV export and every "next free" click, even though the page then collapses
almost all of that into a handful of run rows. The detail page's default (collapsed) view is now built
from the addresses that actually have something to show - a lease, a reservation, an infrastructure
address, or an entry of its own - with the ranges between them turned into run rows directly from the
pool boundaries, never enumerating an address that will only ever read "available". Next-free walks the
subnet lazily and stops at the first free address outside every pool, instead of composing every address
first. CSV export streams one row at a time. Showing every address (`?all=1`) still exists, exactly as
before, but only up to a /22 (1,022 hosts); above that it is refused with a message rather than building
or rendering tens of thousands of rows. A Kea subnet larger than a /16 - the same cap unmanaged subnets
have always had - now gets the same refusal on the detail page and on export that an oversized unmanaged
subnet already got when someone tried to add it.

### Fixed: the global search filtered after its own twenty-row limit

Registered as a Jen search provider, IPAM's own query took the newest twenty matches across every subnet
and let Jen's own re-filter drop the ones outside the caller's scope afterward - a restricted caller whose
only match was the twenty-first newest row, behind twenty matches in a subnet they cannot see, got no
results at all. The caller's own subnet scope is now part of the query itself, so the limit applies to
what they may actually see.

### Fixed: the JSON API accepted a status it then silently changed

`POST /api/v1/plugins/ipam/entries` took an unrecognised `status` value and saved the entry as `static`
anyway, the most consequential of the two designations, with a 200 response that gave no sign anything had
been substituted. An explicit status that is not `static` or `planned` is now a 400. A non-object body (an
array, a string, a bare number) is a 400 instead of reaching `.get` and raising, and a non-string `mac` is
a 400 instead of raising inside the MAC parser.

### Fixed: importing a CSV could overwrite a live lease or reservation

The single-entry save form and the JSON API already refuse to newly mark an address static or planned
when a Kea lease or reservation already holds it; the CSV/Netbox import path did not carry the same check,
so an imported row could silently take over an address DHCP was still using. It is checked now, and a
blocked row counts toward the "skipped" total the import reports.

### Changed

- `tools/test_plugin.py` checks that the collapsed detail view (`_build_rows_lazy`) gives byte-for-byte
  the same rows the old full-materialisation path did on the same fixture, that next-free's lazy and
  full-materialisation answers agree, that the search query carries the caller's own scope, that an
  oversized Kea subnet and an over-large `?all=1` are refused before anything is built, and that the
  streamed CSV's rows are the ones expected.

## [1.6.3] - 2026-09-26

The recurring pattern of this round, named as in every plugin release: a route decides access on one
thing and then acts on another. This release is the first deep audit of this plugin, and its main finding
is the opposite shape, a check that was correct and a lookup beside it that was not.

### Fixed: the JSON API answered every allowed call with a server error

`GET /api/v1/plugins/ipam/entries`, `POST /api/v1/plugins/ipam/entries` and `GET
/api/v1/plugins/ipam/next-free/<subnet_id>` (all added in 1.6.0) looked the subnet up through the same helper
the pages use, which asks the *logged-in user* which subnets they may see. A request carrying only a Bearer
key has no logged-in user, so for every subnet the key was allowed to use the call raised and Jen answered
500. Only the refusal path, a 403 for a subnet outside the key's scope, ever worked, and it runs before the
lookup, so it was the only thing anyone had tested. The API now decides access with the key's own scope
(`api_key_can_access_subnet`; a key with no scope reaches every subnet, a scoped key only its own, a missing
key nothing) and takes the subnet's address range from Jen's unfiltered subnet map. A scoped key still gets
the same 403 for a subnet that does not exist as for one it may not see. If you scripted against this API in
1.6.0 to 1.6.2 and gave up on it, it works now. The plugin's own check no longer patches the access helper
out of the way: it calls the three routes with no session at all, as the API is called, and expects answers.
Because it now uses `api_key_can_access_subnet`, the plugin requires Jen 5.65.2.

### Fixed: an address that only a global reservation holds could be handed out

Kea can hold a reservation that belongs to no subnet (a global one) and applies wherever its fixed address
falls. The plugin read reservations per subnet only, so a global reservation's address showed as available,
and "next free", the API, the range operations' skip list and the utilisation counts treated it as free. It
is now read with the subnet's own reservations, kept only when its address is inside the subnet, and a global
reservation in some other subnet is not counted in this one's total. "Active lease" now means what Jen means
everywhere else, state 0 and not yet expired; it used to be state 0 alone.

### Changed: the conflict check no longer builds every address of every subnet

Every fifteen minutes the conflict job composed the full address table of each Kea subnet (65,534 rows for a
/16) and asked the devices table about each lease and reservation MAC one at a time, although the check never
reads a device. A conflict is an address with a live lease, no reservation and a static or planned entry, so it
is now set arithmetic over the two Kea sets and the subnet's entries. It finds the same conflicts as the page
does (the harness checks the two agree) and asks the database for a handful of rows per subnet.

### Fixed: smaller findings from the same audit

- Marking an address static or planned when a DHCP lease or a Kea reservation already holds it is now refused
  with a message, in the edit form and in the API (409). The range action already skipped such addresses; the
  single-entry paths accepted them and the page then showed a conflict nobody had meant to create. An address
  that is already designated stays editable, so a conflict that arose the other way round can still be worked on.
- Deleting an unmanaged subnet also deletes its assignment history; the rows were left behind with nothing
  pointing at them.
- The per-address history endpoint flashed "You do not have access" and then answered 404 as JSON, so the
  message appeared on the next page the person opened. JSON routes no longer queue a flash.
- The global search treated `%` and `_` in the query as wildcards (a search for `10.0_1` matched `10.0x1`, and a
  lone `%` matched everything). They are literal now, and only Kea-subnet entries are selected in the query,
  where they used to be filtered after a limit of twenty.
- The status filter on the address page is written into its script with `|tojson`, not as bare text.
- The overview's hint no longer says the detail page collapses runs only above a /22; it has done so on every
  subnet since 1.6.1.

### Changed

- `tools/test_plugin.py` calls the API routes with no session and an unrestricted key and expects answers,
  checks a scoped key, a missing key and an unknown subnet, reads the Kea sets from a fake connection (global
  reservations in and out of the subnet, the expiry condition), and compares the conflict arithmetic with the
  per-address composition. Its stub `jen.plugin_api` now carries a faithful `api_key_can_access_subnet`.
- `tools/verify.py` fails a template that has a POST form with no `csrf_token`, the check Jen's own tests make.

## [1.6.2] - 2026-09-25

### Fixed: creating and deleting unmanaged subnets was open to any admin

An unmanaged subnet belongs to no Kea subnet, so who can *see* one is decided by whether the account can see every subnet, while who could *create* or *delete* one was decided by "is an admin" alone. A subnet-scoped admin could therefore add unmanaged subnets they would never be able to see, delete one by a guessed id, and read the names and CIDRs of hidden unmanaged subnets out of the overlap messages. Because the overlap check against Kea subnets ran over the caller's *own* subnets only, they could also create an unmanaged network overlapping a Kea subnet they cannot access. Adding and deleting an unmanaged subnet, and the "Add Unmanaged Subnet" button, now need an administrator who can see every subnet, and the overlap checks run over every Kea subnet Jen knows. The pattern this round names in every plugin: a route authorises on one thing (an "admin" role) and acts on another (an object the caller is not allowed to see).

### Fixed: raw exception text reached the browser and the API

A failed save, import, range action or subnet change put the database's own error message into the page, and the JSON API's entry save returned it in the response body. The details are now written to Jen's log and the caller gets a generic message. (A too-large upload still says so: that message is written for the user, not taken from an exception.)

### Changed

- `tools/test_plugin.py` now runs the add and delete routes with a subnet-scoped admin and an unrestricted one, checks the overlap runs over the full Kea map and that the refusal names nothing hidden, and checks the API's failure response.

## [1.6.1] - 2026-09-25

### Fixed: the subnet page rendered every address of a /24

Runs of available addresses collapsed into one row only on a /22 or larger
(`_COLLAPSE_PREFIX = 22`), so a /24 — the size nearly every subnet is — drew all
254 rows. On the CI phone capture that was a page 33,512 px tall (11,337 px on a
desktop), nearly all of it empty addresses. Runs now collapse at every prefix
length: a busy /24 with a handful of leases and static entries is around fifteen
rows. A run of fewer than four available addresses still shows as individual rows
(a summary row would be longer than the rows it replaces), `?all=1` still shows
every address, and clicking a run still expands just that run. The decision is one
small pure function (`_should_collapse`), and the harness now checks it at each
prefix length, checks that collapsing loses no address, and checks the
four-address floor.

### Changed

- Every remaining inline `style=` attribute is gone from the three templates. The
  usage-bar segments carry their width as a class (`ip-w0` … `ip-w100`, generated
  in the page's own `<style>` block, because the value is computed per render),
  modals use a class instead of `display:none;position:fixed;…`, and the four
  elements that start hidden and were shown by setting `style.display = ''` now
  toggle a class. `tools/verify.py` now fails a template that carries a `style=`
  attribute, so they cannot drift back.
- `tools/test_plugin.py` now calls the real `register(app)` against a stub that
  enforces Jen's two registration rules (an alert type id must start with the
  plugin's own id, a periodic job may not run more often than every five
  minutes). Watchdog and DNS Sync shipped unable to load because nothing ever ran
  `register()`; this harness predates that lesson and now applies it.

### Checked, not changed: the round's authorization pattern

The pattern named across this round's plugin releases — a route authorises on one
thing (a typed subnet id, or nothing for a by-id POST) and acts on another — is
not present here: every IPAM route, the JSON API included, checks the subnet it
acts on, and Jen's authorization matrix covers the plugin's client-facing routes.
No access rule changed in this release.

## [1.6.0] - 2026-09-23

### Sprite icons, a rowlist address table, an alert on new conflicts, a JSON API, and a search provider — built on Jen's plugin API v3

Every emoji in the two pages is now a sprite icon via Jen's own
`icon()` global, and the 187 inline `style="…"` attributes across
`index.html`, `subnet.html` and `import_preview.html` are gone — moved
into named classes in a page-local `<style>` block, following the same
convention Jen's own `tools/extract_inline_styles.py` uses (a Jinja-
driven width, or a `display:none`/`position:fixed` modal, stays
inline; everything else doesn't). The subnet detail page's address
table is now a `rowlist` with `data-m` on every cell, so it degrades
sanely on a phone instead of forcing horizontal scroll.

A new periodic job checks every Kea subnet every 15 minutes for
addresses designated static or planned that a DHCP client currently
holds — a conflict IPAM has always been able to *show*, but never
raised a finger about. The first time a given address is seen in
conflict it now sends an alert (a new `ipam_conflict` type, editable
like any core alert template under Settings → Alerts) and writes an
event Jen's Timeline and Client Investigation can see; a conflict that
resolves and later recurs alerts again, the same "new occurrence only"
rule Network Discovery uses for rogue devices.

Two more things a plugin author asked for: `GET/POST /api/v1/plugins/ipam/entries`
and `GET /api/v1/plugins/ipam/next-free/<subnet_id>`, authenticated the
same way Jen's own REST API is, scoped to whatever subnets the calling
key can see; and IPAM entries now show up in Jen's global search by
label, owner, IP or hostname, subject to the same subnet access every
other search result respects.

Requires Jen 5.57.0 (plugin API v3) — the alert-type registry, the
event bus, the row-action hook (a new "Open in IPAM" action on
reservation rows), API-key routes, and the search-provider hook all
shipped there.

## [1.5.2] - 2026-09-23

### Viewers were never actually read-only, and an import upload had no size cap

Jen's viewer tier is read-only everywhere else, but IPAM Lite's five
write routes — saving or deleting an entry, a range action, and both
steps of a CSV import — checked only subnet access, never the role.
The templates hid the buttons from viewers, so the UI looked
read-only while the routes underneath it were not. Every write route
now refuses a viewer up front, before it even looks at the subnet or
the submitted form, with a plain "Viewers can look at IPAM but not
change it."

Separately, a CSV import read the whole uploaded file into memory
before its 2,000-row cap ever applied, and Jen itself sets no upload
size limit. Uploads are now capped at 2 MB — about 40x the row cap at
a typical export's row width — checked both off the browser's
declared size and against the bytes actually read, so neither an
honest nor a lying upload gets past it. No functional change for a
legitimate import. Requires Jen 5.34.0 or later, unchanged.

## [1.5.1] - 2026-09-15

### Imports only `jen.plugin_api`

Jen 5.34.0 introduces one import surface for plugins, `jen.plugin_api`
— a versioned re-export of what plugins have needed so far, so a rename
inside Jen can never silently break a plugin again. IPAM Lite now
imports from it and nowhere else inside `jen`, and its manifest
declares `"plugin_api": 1`. No functional change. **Requires Jen
5.34.0 or later** (a 5.34.0 beta counts).

## [1.5.0] - 2026-09-13

### Uses everything Jen already knows about a subnet

IPAM Lite was born out of not wanting to populate Netbox when all the
information needed is already in Jen — but until now it only used two
pieces of it (Kea's leases and reservations) and treated everything
else in a subnet as "available". This release reads the rest, through
Jen v5.30.0's `subnet_context` (so **Jen 5.30.0 or later is required**):

- **Gateway, DNS servers, the Kea servers' and the Jen host's own
  addresses, network and broadcast** are a new **Infrastructure**
  status — labelled for what they are, counted as used, never offered
  as free. An unmanaged subnet can record its gateway when it's added
  (a new optional field) for the same effect.
- **DHCP pools** are shown under the subnet header and every address
  inside one carries a `pool` badge. That's what makes **✨ Next free**
  possible: one click finds the first available address *outside*
  every pool — the thing Netbox was being kept around for — and opens
  it for editing.
- **The devices table.** A lease's row now shows the device Jen has
  seen for that MAC (name, vendor, icon) in its own column, and the
  edit form prefills Owner from the device's owner.
- **Subnet notes** from Jen's Subnets page appear under the header.

### Conflicts are conflicts

A `static` or `planned` entry whose address now carries a dynamic
lease used to be shown as plain "Dynamic" — the lease silently won.
It's now a **Conflict** (its own red count, filter tab and status),
showing both the designation and the lease's hostname/MAC, with the
lease link beside it. The fix is either a reservation for the intended
device or a corrected entry; IPAM won't guess.

### Big subnets

- The overview no longer builds the full address space of every subnet
  just to count it (a /16 was 65,534 entries plus two queries per card
  on every load): counts come from set arithmetic over the lease,
  reservation and entry sets.
- The detail page collapses runs of four or more consecutive available
  addresses into one row (`10.0.0.20 – 10.0.0.199 · 180 available`),
  split at pool boundaries; click a run to expand it, or "show every
  address". Subnets up to a /22 still list everything.

### Range operations, history, and the rest

- **Range…** marks a from–to span Planned or Static with one label and
  owner, or clears it — up to 1024 addresses per action, never touching
  an address with a Kea lease or reservation, one history row each.
- **History is finally visible**: the last changes to an address in
  its edit modal, a "Recent changes" panel on the subnet page, and a
  history CSV. Migration 14 indexes the history table for it.
- Manual **hostname and MAC are allowed on Kea-subnet entries** too (the
  columns always existed; only unmanaged subnets could use them) — a
  genuinely static host has a MAC the operator knows, and Network
  Discovery v1.1.0 matches on it.
- `?ip=` on a subnet page opens that address for editing (Network
  Discovery's "Add IPAM entry" link uses it).
- **Netbox-shaped export** (`address, status, dns_name, description,
  tenant`) beside the Jen CSV, for anyone keeping both.
- Every CSV cell goes through Jen's formula-injection guard (a cell
  starting with `=`, `+`, `-`, `@` is quoted); a local copy of the rule
  applies on older Jens.

### Housekeeping

- `tools/test_plugin.py`: the plugin's own unit checks (space
  composition, counting, run collapsing, next-free, ranges, import
  parsing) run in CI after `verify.py`, with no Jen or database needed.
- Migrations 14 (history index) and 15 (`ipam_subnets.gateway`) are
  plain portable DDL like the rest.

## [1.4.6] - 2026-09-13

### Housekeeping: the IPv4-only note, back from the bundled copy

Jen v5.0's IPv6 rollout added a gated "IPAM Lite tracks IPv4 addresses
only" notice to the overview page (shown only when Jen's IPv6 support
is enabled) and an "IPv4 only" scope note to the README — but only in
the copy bundled inside `jen-kea`, never here; Jen's own test suite
checks for both, and caught the gap the moment the bundled copy was
resynced from this repo. Both are now here, so the two copies are
identical. No functional change.

## [1.4.5] - 2026-09-13

### Housekeeping: same lint rules as Jen

Jen bundles a byte-for-byte copy of this plugin under
`jen-kea/plugins/ipam/` and lints its whole tree in CI with its own,
stricter ruff configuration (`ruff check .` and `ruff format --check
.`). This repo's `ruff.toml` is now identical to Jen's, ruff is pinned
to the same version in CI, and `plugin.py` is reformatted to match —
so a resync into Jen can never fail Jen's lint. Mechanical only: import
ordering, formatting, and two unused loop variables renamed. No
functional change.

## [1.4.4] - 2026-09-13

### Fix: migrations were MariaDB-only — installs on MySQL 8 could never migrate

Every schema change since v1.3.0 used MariaDB's `ALTER TABLE … ADD
COLUMN IF NOT EXISTS` / `DROP INDEX IF EXISTS` / `ADD … KEY IF NOT
EXISTS` forms. MySQL 8 has no `IF [NOT] EXISTS` for those, so on a
Jen running against MySQL the first ALTER (migration 4) was a syntax
error, the migration run stopped there, and — since Jen v5.28.1 gates
activation on migrations — the plugin never enabled. Jen supports both
databases; this plugin only ever worked on one.

The migrations are now plain, portable DDL, and the manifest uses
Jen's explicit `{version, description, sql}` format instead of the
flat positional list, so each migration's number is pinned in the file
rather than implied by its position. Versions 1–13 map one-to-one onto
the old positions, so an existing install (which has all thirteen
recorded) runs nothing new; a fresh install runs all thirteen on
either database.

Idempotency moved from the SQL to Jen: **this release requires Jen
v5.28.2**, whose migration runner treats "duplicate column", "duplicate
key name" and "can't DROP — doesn't exist" as *already in the desired
state* and records the migration as applied rather than failing. That
is what lets migration 8 (`DROP INDEX ip`, which undoes v1.1.0's
`UNIQUE` on `ip`) run cleanly on a fresh database that never had that
index, without MariaDB's `IF EXISTS`. On an older Jen the manifest is
refused at install time with the usual "requires Jen …" message.

## [1.4.3] - 2026-09-13

### Housekeeping: dead `.enabled` marker, stale install docs

Dropped the in-tree `.enabled` file — Jen has kept its enable marker
outside the plugin directory (`/var/lib/jen/plugins-enabled/`) since
v5.13.0, so the one shipped in the zip did nothing. The README's manual
install steps still told you to `touch .enabled` in `/opt/jen/plugins`,
a path Jen no longer installs to; they now describe the Settings →
Plugins install (the registry-pinned, checksum-verified path) and the
actual manual location. Added a Development section covering
`tools/verify.py --build` and what CI enforces. No code changes.

## [1.4.2] - 2026-09-13

### Fix: unmanaged subnets ignored Jen's subnet restrictions

Every route gates a Kea-managed subnet through Jen's own subnet-access
check, so a user restricted to specific subnets only ever sees those.
Unmanaged subnets had no equivalent check at all — only "logged in" —
so a subnet-restricted viewer could open, export, annotate, and clear
entries on *any* unmanaged subnet, and the overview page listed them
all regardless. Unmanaged subnets aren't part of Jen's subnet map, so
there's no per-subnet grant to consult; the fix treats them like any
other out-of-scope subnet: a user whose access is restricted to
specific Kea subnets gets none of them, on the overview and on every
detail/edit/import/export route. Unrestricted users and superadmins
see no change.

Separately, the entry save/clear routes answered an access-denied
POST with a raw JSON `403` — but the forms that post to them are plain
HTML forms, so the browser just showed `{"error": "Access denied"}` as
a page. They now flash and redirect like every other error path.

### Fix: Content-Security-Policy compatibility (no inline scripts)

Jen v5.22.0 dropped `'unsafe-inline'` from its script-src CSP — every
`<script>` tag now needs a per-request nonce, and inline event-handler
attributes (`onclick=`, `oninput=`, `onmouseover=`, etc.) are simply
never executed under that policy. This plugin's two templates
(`index.html`, `subnet.html`) still had ~19 inline handlers and two
un-nonce'd `<script>` blocks from before that change, so every button,
filter tab, and the per-row edit action silently stopped working the
moment CSP enforcement was turned on — nothing errored, the browser
just refused to run the attribute.

Every inline handler is now bound via `addEventListener` (delegated on
the containers that already existed — `#filter-tabs`, `#ipam-table` —
for the per-row edit button and the filter tabs, so a new row or a new
tab doesn't need a new listener), both `<script>` blocks carry
`nonce="{{ csp_nonce }}"`, and the two `onmouseover`/`onmouseout`
handlers on the subnet-card hover effect became a plain CSS `:hover`
rule instead of JS entirely. No functional or visual change — every
button does exactly what it did before, just via a CSP-compliant
binding.

Also corrected `manifest.json`'s `changelog_url`, which pointed at the
copy of this file bundled inside the main `jen-kea` repo instead of
this repo's own — stale since this plugin was split out on its own.

## [1.4.1] - 2026-08-23

### Fix: version-bump-only release — v1.4.0 never actually shipped

v1.4.0's source was correct, but the repo's `plugin.zip` — the actual
artifact Jen's Update button downloads from `raw/main/plugin.zip` —
wasn't rebuilt alongside it, so the update silently kept installing the
old v1.3.3 code. No functional changes from what v1.4.0 was meant to
be; this release exists only to get a correctly-built `plugin.zip` onto
`main` under a version number that was never live. See v1.4.0 below for
the actual feature changes (import, Planned status, auto-detect
Static).

## [1.4.0] - 2026-08-23

### Feature: import from Netbox, Jen's own export, or other CSV sources

New "⬆ Import" button on each subnet's detail page. Upload a CSV and
pick a source:

- **Jen IPAM export** — round-trips Jen's own `Export CSV` output.
  Rows with `status=dynamic`/`reserved` are skipped on import (that's
  Kea-derived state, not a manual IPAM annotation); `static` and
  `planned` rows import as-is.
- **Netbox** — reads a Netbox "IP Addresses" export. Matches `address`
  (tolerates the `10.0.0.5/24` CIDR form Netbox uses), `status`,
  `dns_name`, `description`/`comments`, and `tenant`. Netbox's
  `reserved` status maps to Jen's new `planned` status (see below) —
  both mean "set aside, not actively assigned yet." `dhcp`/`slaac`
  rows are skipped since Kea already owns that state for managed
  subnets.
- **Generic CSV** — column-name sniffing for anything else (`ip`/
  `address`, `label`/`name`, `owner`/`tenant`, `notes`/`description`,
  `hostname`, `mac`, `status`), so exports from other tools can be
  imported without a Jen- or Netbox-specific format.

Nothing is saved on upload. Import is a two-step preview → confirm
flow: rows outside the target subnet's CIDR are filtered out and
counted, the parsed rows are shown in a table, and only "Confirm
Import" writes to `ipam_static_entries` (upserted the same way a
manual edit is — importing the same IP twice just updates it). Each
import writes a summary line to the audit log and one `import` row
per address to `ipam_assignment_history`. Capped at 2000 importable
rows per file.

### Feature: third "Planned" status, and auto-detecting Static on edit

The edit-address modal previously offered only Available and Static.
Two related changes:

- Typing into Label/Owner/Notes (or Hostname/MAC on unmanaged subnets)
  while an address is still set to Available now switches the Status
  dropdown to Static automatically, rather than silently leaving it as
  a plain annotation. Clearing those fields back to empty switches it
  back to Available. Manually picking a status yourself (including
  picking Available back again, or picking Planned) is respected for
  the rest of that modal session — the auto-switch only ever acts on
  an untouched Available dropdown.
- Added a third status, **Planned** — "earmarked for future use,"
  distinct from a Kea reservation (`reserved` status is Kea's own DHCP
  reservation and is unrelated). Shown throughout with a violet ◔/●
  marker: subnet summary card, filter tabs, table rows, edit modal,
  index-page subnet cards and legend, CSV export, and import preview.

DB: new `entry_status` column on `ipam_static_entries`
(`static`/`planned`/`available`), backfilled once from the existing
`is_static` flag. `is_static` is kept in sync going forward for
backward compatibility rather than dropped.

### Fix: reservation quick-link now shows for Planned addresses

The 📌 "Create Reservation" quick-link in the table's action column
previously only appeared for Available and Static rows; it now also
appears for Planned, since a planned address is exactly the kind of
row someone is likely to turn into a real reservation next.

## [1.3.3] - 2026-08-15

### Feature: multi-select status filtering on the subnet detail page

Requested directly: previously the status filter tabs (All / Available
/ Dynamic / Reserved / Static) were single-select — clicking one
deselected any other. Now Available/Dynamic/Reserved/Static toggle
independently and can be combined (e.g. show Reserved + Static
together, excluding Available/Dynamic), while "All" remains a distinct
action that clears back to showing everything rather than being one
more option to combine with the others. Deselecting the last active
filter falls back to "All" automatically rather than leaving a
confusing empty table with no obvious way back.

Pure client-side change — `_currentFilter` is now a `Set` instead of a
single string, with `toggleFilter(f)` replacing the old `setFilter(f)`
for the four specific status buttons and a new `setFilterAll()` for
the "All" button specifically. No backend or database changes.

**Verification:** the actual filter logic (not a reimplementation of
it) was extracted and run directly under Node.js against 13 scenarios
covering the exact requested behavior — toggling multiple filters on
together, toggling one back off while others remain active, the
empty-selection fallback to "All", and a three-way combination — all
passed. No headless browser was available to click-test the UI itself,
so this covers the actual selection/matching logic precisely rather
than the full rendered page.

## [1.3.2] - 2026-08-15

### Fixed: every POST form was missing its CSRF token — guaranteed 403 on save/delete/add-subnet

**Bug** — none of this plugin's four POST forms (`edit-form` /
save_entry, `clear-form` / delete_entry, `subnet-delete-form` /
delete_subnet, and the add-unmanaged-subnet form) included a
`csrf_token` hidden input. `csrf_token()` is registered as an
app-wide Jinja global by Jen's core `context_processor` and is
genuinely available inside plugin templates — it was just never
called in any of these four forms. Every submission through any of
them hit Jen's CSRF middleware and got rejected with a 403
"session security token is missing or expired," regardless of how
valid the actual session was.

**Fix** — `<input type="hidden" name="csrf_token" value="{{ csrf_token() }}">`
added to all four forms in `templates/ipam/subnet.html` and
`templates/ipam/index.html`.

**Verification** — reproduced against this plugin's own real code
running inside a real Jen instance: real login, real session, real
CSRF middleware enabled (the test suite it was found from normally
runs with CSRF checks off, which is exactly why this had no test
coverage). Confirmed all four forms genuinely 403 before the fix and
genuinely succeed after it, using a token actually extracted from the
real rendered page rather than a synthetic one — including this
plugin's own DB migrations and full `kind`-parameterized route set
(`/entry/<kind>/<subnet_id>`, `/subnets/add`, `/subnets/<id>/delete`),
not just the simpler bundled copy of this plugin that ships inside
jen-kea itself (which had the same bug, fixed separately there).

## [1.3.1] - 2026-08-03

### Fix: superadmin couldn't see or use unmanaged subnet controls

**Bug** — `_is_admin()` checked `role == "admin"` only. Jen's actual role system is three-tier (`superadmin` > `admin` > `viewer`, per `jen/services/access.py`), so a `superadmin` account — the top-level role most installs actually log in as — evaluated as *not* admin. This hid the **＋ Add Unmanaged Subnet** button entirely and would have blocked subnet delete as well, even though `admin` accounts worked fine.

**Fix** — `_is_admin()` now delegates to Jen's own `is_admin_or_above()` helper instead of re-deriving role logic in the plugin, so it can't drift out of sync with core again.

## [1.3.0] - 2026-08-03


### Unmanaged subnets + audit fixes

**Unmanaged subnet support** — IPAM Lite is no longer limited to Kea-managed subnets. Admins can add non-DHCP subnets (e.g. a backend network) from the overview page via **＋ Add Unmanaged Subnet** (name, CIDR, description). Unmanaged subnets:
- Appear on the overview alongside Kea subnets with an **unmanaged** badge
- Never query Kea — addresses are only Available or Static
- Support per-address **manual hostname and MAC** fields (since there's no DHCP to supply them), with MAC validation and normalisation
- Can be deleted (admin only) from the detail page, cascading their entries
- Reject CIDRs that overlap any Kea-managed or existing unmanaged subnet; hard cap at /16, warning above /22
- Are visible to all authenticated users; add/delete is admin-only

**Schema changes** (idempotent migrations):
- New `ipam_subnets` table
- `subnet_kind` discriminator on `ipam_static_entries` and `ipam_assignment_history`
- `hostname`, `mac`, `is_static` columns on `ipam_static_entries`
- The global `UNIQUE(ip)` is replaced with `UNIQUE(ip, subnet_kind, subnet_id)` — previously an entry saved in one subnet could silently overwrite the same IP string tracked in another subnet
- New index on `(subnet_kind, subnet_id)`

**Audit fixes:**
- Reservation identifiers are only rendered as MACs when `dhcp_identifier_type` is hw-address; other identifier types (client-id, DUID, circuit-id) display as labelled hex instead of garbage, and over-length identifiers are no longer silently truncated
- Reservations with NULL/zero `ipv4_address` (hostname-only / option-only) are excluded from the address-space query
- DB connections are now released in `finally` blocks — previously an exception mid-query stranded a pooled connection
- "Available with annotation" is now a real state: `is_static` is stored explicitly, so saving an annotated IP with status Available no longer forcibly displays it as Static (existing entries migrate as Static, preserving current behaviour)
- Saved IPs are validated as belonging to the subnet's CIDR
- All plugin-written timestamps now use `UTC_TIMESTAMP()` per Jen's UTC-throughout convention
- CSV export filename is sanitised (subnet names with spaces/quotes no longer malform the `Content-Disposition` header)
- The `filter` query parameter is whitelisted server-side
- Edit modal data is passed via `data-entry` JSON attributes instead of hand-escaped inline JS arguments
- The ✕ clear-search button described in the 1.2.0 changelog now actually exists
- Per-subnet summary errors on the overview are logged instead of silently swallowed
- Redundant class-swap logic in the filter-tab JS replaced with `classList.toggle`

## [1.2.1 – 1.2.3]

Changelog entries were not recorded at release time.

## [1.2.0] - 2026-06-09

### Search, MAC display, quick links

**Live search** — A search box above the address table filters as you type across IP address, hostname, label, MAC, owner, and notes simultaneously. No page reload — purely client-side filtering so it works instantly across all 500+ addresses in a /23. Combines with the status filter tabs: you can filter to "Reserved" and search within those results. A result count shows how many addresses match. An ✕ button clears the search.

**MAC address column** — MAC addresses for dynamic and reserved IPs are now always visible in the table rather than only appearing in the edit modal. Useful for cross-referencing with physical hardware.

**Quick action links** — second button per row based on IP status:
- Available / Static → 📌 "Create Reservation" — opens the Add Reservation form with the IP pre-filled
- Dynamic → 🔗 "View Lease" — links to Leases page filtered to that IP
- Reserved → 🔗 "View Reservation" — links to Reservations page filtered to that IP

**Filter tabs are now client-side** — the status filter tabs no longer reload the page; they use the same JS filtering as search. Switching between All/Available/Dynamic/Reserved/Static is instant.

## [1.1.0] - 2026-06-09

### Edit modal UX overhaul

- **Single ✏️ button** per row replaces the scattered "+ Note" / "Edit" / "✕" buttons
- **Context-aware modal** — fields shown depend on the IP's current status:
  - Dynamic / Reserved: Notes field only (label/owner/status are read-only from Kea). Kea hostname and MAC shown as read-only info.
  - Available / Static: Status selector (Available ↔ Static), Label, Owner, Notes all editable
- **Status selector** for available/static IPs — mark an address as Static to designate it as intentionally assigned outside the DHCP pool (router, NAS, printer, etc.)
- **"Clear all notes"** button in the modal removes the IPAM entry entirely
- Setting status back to Available with no other fields also clears the entry cleanly

## [1.0.0] - 2026-06-08

### First full release

- **Overview page** — all accessible subnets shown as cards with stacked utilisation bars (dynamic/reserved/static/available) and percentage used
- **Subnet detail page** — full address space table showing every IP in the pool with its current status
- **Status types:** Available (no lease/reservation/note), Dynamic (active DHCP lease), Reserved (Kea reservation), Static (manually noted)
- **Notes/annotations** — click "＋ Note" on any IP to add a label (e.g. "NAS"), owner (e.g. "Matthew"), and free-text notes. Edit or remove at any time.
- **Filter tabs** — filter the address table by status (All / Available / Dynamic / Reserved / Static)
- **CSV export** — download the full address space as CSV for any subnet
- **Assignment history** — every add/edit/remove is logged to `ipam_assignment_history` with user and timestamp
- **Subnet access control** — respects Jen's role-based subnet restrictions

## [0.1.0] - 2026-06-05

- Stub plugin for framework testing
